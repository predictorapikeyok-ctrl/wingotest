import json

# We will construct the complete stickerData from user request
# User provided: var stickerData = {"tgs":1,"v":"5.5.2","fr":60,"ip":0,"op":180,"w":512,"h":512,"nm":"pravki","ddd":0,"assets":[],"layers":[... 52 layers ...]};

# Let's write the complete JSON accurately:
with open('/tmp/user_raw_data.json', 'w') as f:
    pass
