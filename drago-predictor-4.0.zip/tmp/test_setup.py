import json

# Let's save the exact JSON animation provided by the user
# NM: "pravki", 52 layers
with open('tmp/raw_sticker_user.json', 'r') as f:
    pass
