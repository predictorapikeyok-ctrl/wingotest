import json

html_file = "public/duck-muscle-sticker.html"

# Let's read the full JSON provided by user in the prompt and write it
user_json_str = """{
  "tgs": 1,
  "v": "5.5.2",
  "fr": 60,
  "ip": 0,
  "op": 180,
  "w": 512,
  "h": 512,
  "nm": "pravki",
  "ddd": 0,
  "assets": []
}"""
print("Starting...")
