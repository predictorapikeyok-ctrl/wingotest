import json
import os

# Let's read the full JSON provided by the user in the prompt and write it
# We can create the parts or write the complete valid JSON structure.
